window.onload = ()=>{
 
    if (window.location.pathname == "/pages/test-registration-form") {
        const firstNameField = document.getElementById("RegisterForm-FirstName")
          , lastNameField = document.getElementById("RegisterForm-LastName")
          , emailField = document.getElementById("RegisterForm-email")
          , passwordField = document.getElementById("RegisterForm-password")
       
          , firstNameLabel = document.querySelector('label[for="RegisterForm-FirstName"]')
          , lastNameLabel = document.querySelector('label[for="RegisterForm-LastName"]')
          , emailLabel = document.querySelector('label[for="RegisterForm-email"]')
          , passwordLabel = document.querySelector('label[for="RegisterForm-password"]');

      firstNameField.addEventListener("focus", ()=>{
            firstNameLabel.style.fontSize = "1rem",
            firstNameLabel.style.top = "calc(var(--inputs-border-width) + 0.5rem)",
            firstNameLabel.style.letterSpacing = "0.04rem"
        }
        ),
        firstNameField.addEventListener("blur", ()=>{
            firstNameField.value.trim() == "" && (firstNameLabel.style.fontSize = "1.6rem",
            firstNameLabel.style.top = "calc(1rem + var(--inputs-border-width))",
            firstNameLabel.style.letterSpacing = "0.1rem")
        }
        ),
        lastNameField.addEventListener("focus", ()=>{
            lastNameLabel.style.fontSize = "1rem",
            lastNameLabel.style.top = "calc(var(--inputs-border-width) + 0.5rem)",
            lastNameLabel.style.letterSpacing = "0.04rem"
        }
        ),
        lastNameField.addEventListener("blur", ()=>{
            lastNameField.value.trim() == "" && (lastNameLabel.style.fontSize = "1.6rem",
            lastNameLabel.style.top = "calc(1rem + var(--inputs-border-width))",
            lastNameLabel.style.letterSpacing = "0.1rem")
        }
        ),
        emailField.addEventListener("focus", ()=>{
            emailLabel.style.fontSize = "1rem",
            emailLabel.style.top = "calc(var(--inputs-border-width) + 0.5rem)",
            emailLabel.style.letterSpacing = "0.04rem"
        }
        ),
        emailField.addEventListener("blur", ()=>{
            emailField.value.trim() == "" && (emailLabel.style.fontSize = "1.6rem",
            emailLabel.style.top = "calc(1rem + var(--inputs-border-width))",
            emailLabel.style.letterSpacing = "0.1rem")
        }
        ),
        passwordField.addEventListener("focus", ()=>{
            passwordLabel.style.fontSize = "1rem",
            passwordLabel.style.top = "calc(var(--inputs-border-width) + 2.5rem)",
            passwordLabel.style.letterSpacing = "0.04rem"
        }
        ),
        passwordField.addEventListener("blur", ()=>{
            passwordField.value.trim() == "" && (passwordLabel.style.fontSize = "1.6rem",
            passwordLabel.style.top = "calc(3rem + var(--inputs-border-width))",
            passwordLabel.style.letterSpacing = "0.1rem")
        }
        )
    }
}
;
